#!/bin/sh
./jre11/bin/java -jar ExtractVideos-portable.jar
